import { Ionicons } from "@expo/vector-icons";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { api, apiConfig } from "../api/client";
import type { Conversation, Message, UUID } from "../api/types";
import { Button } from "../components/Button";
import { Field } from "../components/Field";
import { useApp } from "../state/AppContext";
import { colors } from "../theme/colors";

type Props = {
  initialConversationId?: UUID;
  initialParticipantId?: UUID;
  initialParticipantName?: string;
  onBack?: () => void;
};

export function ChatScreen({
  initialConversationId,
  initialParticipantId,
  initialParticipantName,
  onBack,
}: Props = {}) {
  const { session, messages, appendMessage, showToast } = useApp();
  const socket = useRef<WebSocket | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [active, setActive] = useState<Conversation>();
  const [participantId, setParticipantId] = useState("");
  const [text, setText] = useState("");

  const activeMessages = active ? messages[active.id] ?? [] : [];
  const initializedParticipantRef = useRef<string | null>(null);

  const loadConversations = useCallback(async () => {
    if (!session) {
      return;
    }
    const result = await api.getConversations(session.token);
    const list = result.data ?? [];
    setConversations(list);

    setActive((prevActive) => {
      if (initialConversationId) {
        const found = list.find((c) => c.id === initialConversationId);
        if (found) return found;
      }
      if (!prevActive && list[0] && !initialParticipantId) {
        return list[0];
      }
      return prevActive;
    });
  }, [initialConversationId, initialParticipantId, session]);

  const loadMessages = useCallback(
    async (conversation: Conversation) => {
      if (!session) {
        return;
      }
      const result = await api.getMessages(session.token, conversation.id);
      result.data.reverse().forEach(appendMessage);
    },
    [appendMessage, session],
  );

  useEffect(() => {
    loadConversations().catch(() => undefined);
  }, [loadConversations]);

  // Handle direct navigation with initialParticipantId (runs once per participant)
  useEffect(() => {
    if (!session || !initialParticipantId) return;
    if (initializedParticipantRef.current === initialParticipantId) return;
    initializedParticipantRef.current = initialParticipantId;

    async function initDirectChat() {
      try {
        const result = await api.createConversation(
          session!.token,
          [initialParticipantId as UUID],
          "DIRECT",
          initialParticipantName || "",
        );
        setActive(result.data);
        const convsRes = await api.getConversations(session!.token);
        setConversations(convsRes.data ?? []);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed to open conversation";
        showToast({
          message: msg.includes("follow")
            ? "⛔ Messaging restricted: either you must follow this user or they must follow you."
            : msg,
          kind: "error",
        });
      }
    }

    initDirectChat();
  }, [initialParticipantId, initialParticipantName, session, showToast]);

  useEffect(() => {
    if (active) {
      loadMessages(active).catch(() => undefined);
    }
  }, [active?.id, loadMessages]);

  useEffect(() => {
    if (!session?.personnelId) {
      return;
    }
    const ws = new WebSocket(`${apiConfig.socketUrl}?id=${session.personnelId}`);
    socket.current = ws;
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "error" || data.error_code === "FOLLOW_REQUIRED") {
          showToast({
            message: data.message || "Messaging restricted: either user must follow the other to exchange messages.",
            kind: "error",
          });
          return;
        }
        appendMessage(data as Message);
      } catch {
        showToast({ message: "Received an invalid realtime event", kind: "error" });
      }
    };
    ws.onerror = () => showToast({ message: "Realtime chat disconnected", kind: "error" });
    return () => ws.close();
  }, [appendMessage, session?.personnelId, showToast]);

  async function createConversation() {
    if (!session || !participantId) {
      return;
    }
    try {
      const result = await api.createConversation(
        session.token,
        [participantId as UUID],
        "DIRECT",
      );
      setParticipantId("");
      await loadConversations();
      setActive(result.data);
      showToast({ message: "Direct chat opened!", kind: "success" });
    } catch (error) {
      const msg = error instanceof Error ? error.message : "Could not create chat";
      showToast({
        message: msg.includes("follow")
          ? "⛔ Messaging restricted: either user must follow the other to chat."
          : msg,
        kind: "error",
      });
    }
  }

  async function send() {
    if (!session || !active || !text) {
      return;
    }
    try {
      const result = await api.sendMessage(session.token, active.id, text);
      appendMessage(result.data);
      setText("");
    } catch (error) {
      const msg = error instanceof Error ? error.message : "Failed to send message";
      showToast({
        message: msg.includes("follow")
          ? "⛔ Messaging restricted: either user must follow the other."
          : msg,
        kind: "error",
      });
    }
  }

  const activeTitle = active?.name || (initialParticipantName ? initialParticipantName : (active ? `Chat ${active.id.slice(0, 8)}` : ""));

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={styles.screen}
    >
      {/* Top Header when onBack is provided */}
      {onBack && (
        <View style={styles.topHeader}>
          <Pressable onPress={onBack} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </Pressable>
          <View style={styles.headerTitleWrap}>
            <Text style={styles.headerTitle} numberOfLines={1}>
              {activeTitle || "Direct Message"}
            </Text>
            {active && <Text style={styles.headerSubtitle}>Direct Conversation</Text>}
          </View>
          <View style={{ width: 24 }} />
        </View>
      )}

      <View style={styles.sidebar}>
        {!onBack && <Text style={styles.title}>Messages</Text>}
        <View style={styles.createRow}>
          <Field
            label="Participant ID"
            value={participantId}
            onChangeText={setParticipantId}
            placeholder="UUID"
          />
          <Button label="Start chat" onPress={createConversation} />
        </View>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={conversations}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.conversationList}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => setActive(item)}
              style={[styles.conversation, active?.id === item.id && styles.active]}
            >
              <Text style={styles.conversationText}>
                {item.name || item.id.slice(0, 8)}
              </Text>
            </Pressable>
          )}
        />
      </View>

      <FlatList
        contentContainerStyle={styles.messages}
        data={activeMessages}
        keyExtractor={(item, index) => `${item.id}-${index}`}
        ListEmptyComponent={
          <Text style={styles.empty}>
            {active ? "No messages yet. Say hello!" : "Create or select a conversation."}
          </Text>
        }
        renderItem={({ item }) => {
          const mine = item.sender_id === session?.personnelId;
          return (
            <View style={[styles.bubble, mine && styles.mine]}>
              <Text style={[styles.messageText, mine && styles.mineText]}>
                {item.content}
              </Text>
            </View>
          );
        }}
      />
      <View style={styles.composer}>
        <Field
          label="Message"
          value={text}
          onChangeText={setText}
          placeholder="Say something"
        />
        <Button label="Send" onPress={send} disabled={!active || !text} />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  topHeader: {
    height: 52,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    backgroundColor: colors.canvas,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: {
    padding: 4,
  },
  headerTitleWrap: {
    flex: 1,
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.text,
  },
  headerSubtitle: {
    fontSize: 11,
    color: colors.textDim,
  },
  sidebar: {
    padding: 16,
    gap: 12,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.line,
  },
  title: {
    color: colors.ink,
    fontSize: 30,
    fontWeight: "900",
  },
  createRow: {
    gap: 10,
  },
  conversationList: {
    gap: 8,
  },
  conversation: {
    minHeight: 38,
    justifyContent: "center",
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 12,
    backgroundColor: colors.card,
  },
  active: {
    backgroundColor: colors.primary,
    borderColor: colors.cyan,
  },
  conversationText: {
    color: colors.text,
    fontWeight: "800",
  },
  messages: {
    padding: 16,
    gap: 10,
  },
  empty: {
    color: colors.textDim,
    textAlign: "center",
    padding: 30,
  },
  bubble: {
    alignSelf: "flex-start",
    maxWidth: "82%",
    borderRadius: 14,
    padding: 12,
    backgroundColor: colors.cardElevated,
    borderWidth: 1,
    borderColor: colors.border,
  },
  mine: {
    alignSelf: "flex-end",
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  messageText: {
    color: colors.text,
  },
  mineText: {
    color: "#ffffff",
  },
  composer: {
    padding: 16,
    gap: 10,
    backgroundColor: colors.canvas,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
});
