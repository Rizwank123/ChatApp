import React, { useCallback, useEffect, useState } from "react";
import {
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { api } from "../api/client";
import type { Comment, Post } from "../api/types";
import { Button } from "../components/Button";
import { Field } from "../components/Field";
import { useApp } from "../state/AppContext";
import { colors } from "../theme/colors";

type Props = {
  post: Post;
  onBack: () => void;
};

export function CommentsScreen({ post, onBack }: Props) {
  const { session, showToast } = useApp();
  const [comments, setComments] = useState<Comment[]>([]);
  const [content, setContent] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!session) {
      return;
    }
    const result = await api.getComments(session.token, post.id);
    setComments(result.data);
  }, [post.id, session]);

  useEffect(() => {
    load().catch((error) =>
      showToast({
        message: error instanceof Error ? error.message : "Could not load comments",
        kind: "error",
      }),
    );
  }, [load, showToast]);

  async function submit() {
    if (!session || !content) {
      return;
    }
    setBusy(true);
    try {
      await api.createComment(session.token, post.id, content);
      setContent("");
      await load();
    } catch (error) {
      showToast({
        message: error instanceof Error ? error.message : "Could not comment",
        kind: "error",
      });
    } finally {
      setBusy(false);
    }
  }

  async function remove(comment: Comment) {
    if (!session) {
      return;
    }
    await api.deleteComment(session.token, post.id, comment.id);
    load();
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={styles.screen}
    >
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.backButton}>
          <Text style={styles.backText}>Back</Text>
        </Pressable>
        <Text style={styles.title}>Comments</Text>
      </View>
      <FlatList
        contentContainerStyle={styles.list}
        data={comments}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<Text style={styles.empty}>No comments yet.</Text>}
        renderItem={({ item }) => (
          <View style={styles.comment}>
            <Text style={styles.author}>{item.personnel_id.slice(0, 8)}</Text>
            <Text style={styles.commentText}>{item.content}</Text>
            <Pressable onPress={() => remove(item)}>
              <Text style={styles.delete}>Delete</Text>
            </Pressable>
          </View>
        )}
      />
      <View style={styles.composer}>
        <Field
          label="Add comment"
          value={content}
          onChangeText={setContent}
          placeholder="Write a reply"
        />
        <Button label={busy ? "Posting..." : "Post"} onPress={submit} disabled={busy} />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#fafafa",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    gap: 14,
  },
  backButton: {
    minWidth: 52,
    minHeight: 38,
    justifyContent: "center",
  },
  backText: {
    color: colors.jade,
    fontWeight: "800",
  },
  title: {
    color: colors.ink,
    fontSize: 24,
    fontWeight: "900",
  },
  list: {
    padding: 16,
    gap: 10,
  },
  empty: {
    color: colors.muted,
    textAlign: "center",
    padding: 30,
  },
  comment: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 8,
    padding: 12,
    gap: 6,
  },
  author: {
    color: colors.muted,
    fontSize: 12,
    fontWeight: "800",
  },
  commentText: {
    color: colors.ink,
  },
  delete: {
    color: colors.danger,
    fontWeight: "700",
  },
  composer: {
    padding: 16,
    gap: 10,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.line,
  },
});
