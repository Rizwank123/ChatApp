import { Ionicons } from "@expo/vector-icons";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { api } from "../api/client";
import type {
  HashtagSearchResult,
  Post,
  UserSearchResult,
} from "../api/types";
import { useApp } from "../state/AppContext";
import { colors } from "../theme/colors";

const { width } = Dimensions.get("window");
const GRID_ITEM_SIZE = (width - 4) / 3;

const CATEGORIES = ["For You", "Trending", "Cyber", "Music", "Tech", "Art", "Crypto"];
type SearchTab = "Top" | "Accounts" | "Tags" | "Posts";

type Props = {
  onSelectPost?: (post: Post) => void;
};

export function ExploreScreen({ onSelectPost }: Props) {
  const { session, showToast } = useApp();
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("For You");
  const [activeTab, setActiveTab] = useState<SearchTab>("Top");
  const [loading, setLoading] = useState(false);

  // Search Results
  const [users, setUsers] = useState<UserSearchResult[]>([]);
  const [hashtags, setHashtags] = useState<HashtagSearchResult[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);

  // Explore grid posts
  const [explorePosts, setExplorePosts] = useState<Post[]>([]);

  const loadExplore = useCallback(async () => {
    if (!session) return;
    try {
      const feedRes = await api.getExplorePosts(session.token, 0, 36);
      if (feedRes.data && feedRes.data.length > 0) {
        setExplorePosts(feedRes.data);
      } else {
        const fallback = await api.getFeed(session.token, 0, 36);
        setExplorePosts(fallback.data ?? []);
      }
    } catch {
      try {
        const fallback = await api.getFeed(session.token, 0, 36);
        setExplorePosts(fallback.data ?? []);
      } catch {
        // quiet fallback
      }
    }
  }, [session]);

  const runSearch = useCallback(async () => {
    if (!session || !query.trim()) {
      setUsers([]);
      setHashtags([]);
      setPosts([]);
      return;
    }

    setLoading(true);
    try {
      const cleanQuery = query.trim();
      if (cleanQuery.startsWith("#")) {
        const tag = cleanQuery.replace(/^#/, "");
        const [tagDetails, tagPosts] = await Promise.all([
          api.searchHashtags(session.token, tag, 0, 10).catch(() => ({ data: [] })),
          api.getHashtagPosts(session.token, tag, 0, 30).catch(() => ({ data: [] })),
        ]);
        setHashtags(tagDetails.data ?? []);
        setPosts(tagPosts.data ?? []);
        setUsers([]);
      } else {
        const unified = await api.unifiedSearch(session.token, cleanQuery, 15);
        if (unified.data) {
          setUsers(unified.data.users ?? []);
          setHashtags(unified.data.hashtags ?? []);
          setPosts(unified.data.posts ?? []);
        }
      }
    } catch (err) {
      // search silent error fallback
    } finally {
      setLoading(false);
    }
  }, [query, session]);

  useEffect(() => {
    loadExplore();
  }, [loadExplore]);

  useEffect(() => {
    const t = setTimeout(() => {
      runSearch();
    }, 280);
    return () => clearTimeout(t);
  }, [runSearch]);

  const toggleFollow = async (person: UserSearchResult) => {
    if (!session) return;
    const wasFollowing = person.is_following;
    const nextFollowing = !wasFollowing;

    setUsers((prev) =>
      prev.map((p) =>
        p.personnel_id === person.personnel_id
          ? { ...p, is_following: nextFollowing }
          : p,
      ),
    );

    try {
      if (wasFollowing) {
        await api.unfollowSocial(session.token, person.personnel_id);
        showToast({ message: `Unfollowed @${person.user_name}`, kind: "info" });
      } else {
        await api.followSocial(session.token, person.personnel_id);
        showToast({ message: `Following @${person.user_name}`, kind: "success" });
      }
    } catch {
      setUsers((prev) =>
        prev.map((p) =>
          p.personnel_id === person.personnel_id
            ? { ...p, is_following: wasFollowing }
            : p,
        ),
      );
      showToast({ message: "Action failed", kind: "error" });
    }
  };

  const isSearching = query.trim().length > 0;

  return (
    <View style={styles.container}>
      {/* Search Header */}
      <View style={styles.header}>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={18} color={colors.textDim} />
          <TextInput
            placeholder="Search accounts, #tags, posts..."
            placeholderTextColor={colors.textDim}
            style={styles.searchInput}
            value={query}
            onChangeText={setQuery}
            autoCapitalize="none"
          />
          {query.length > 0 && (
            <Pressable onPress={() => setQuery("")}>
              <Ionicons name="close-circle" size={16} color={colors.textDim} />
            </Pressable>
          )}
        </View>
      </View>

      {/* Tabs when search is active */}
      {isSearching && (
        <View style={styles.searchTabs}>
          {(["Top", "Accounts", "Tags", "Posts"] as SearchTab[]).map((tab) => (
            <Pressable
              key={tab}
              onPress={() => setActiveTab(tab)}
              style={[styles.searchTabItem, activeTab === tab && styles.searchTabActive]}
            >
              <Text
                style={[
                  styles.searchTabText,
                  activeTab === tab && styles.searchTabActiveText,
                ]}
              >
                {tab}
              </Text>
            </Pressable>
          ))}
        </View>
      )}

      {loading && (
        <View style={styles.loadingBar}>
          <ActivityIndicator size="small" color={colors.primary} />
        </View>
      )}

      {/* Active Search Mode */}
      {isSearching ? (
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {/* Top Tab: Mixed Preview */}
          {activeTab === "Top" && (
            <View>
              {users.length > 0 && (
                <View style={styles.section}>
                  <Text style={styles.sectionHeader}>Accounts</Text>
                  {users.slice(0, 3).map((u) => renderUserRow(u, toggleFollow))}
                </View>
              )}

              {hashtags.length > 0 && (
                <View style={styles.section}>
                  <Text style={styles.sectionHeader}>Hashtags</Text>
                  {hashtags.slice(0, 4).map((h) => renderHashtagRow(h, (tag) => setQuery(`#${tag}`)))}
                </View>
              )}

              {posts.length > 0 && (
                <View style={styles.section}>
                  <Text style={styles.sectionHeader}>Posts</Text>
                  {renderPostsGrid(posts, onSelectPost)}
                </View>
              )}

              {users.length === 0 && hashtags.length === 0 && posts.length === 0 && !loading && (
                <Text style={styles.emptySearchText}>No results found for "{query}"</Text>
              )}
            </View>
          )}

          {/* Accounts Tab */}
          {activeTab === "Accounts" && (
            <View style={styles.section}>
              {users.length > 0 ? (
                users.map((u) => renderUserRow(u, toggleFollow))
              ) : (
                !loading && <Text style={styles.emptySearchText}>No accounts found</Text>
              )}
            </View>
          )}

          {/* Tags Tab */}
          {activeTab === "Tags" && (
            <View style={styles.section}>
              {hashtags.length > 0 ? (
                hashtags.map((h) => renderHashtagRow(h, (tag) => setQuery(`#${tag}`)))
              ) : (
                !loading && <Text style={styles.emptySearchText}>No hashtags found</Text>
              )}
            </View>
          )}

          {/* Posts Tab */}
          {activeTab === "Posts" && (
            <View style={styles.section}>
              {posts.length > 0 ? (
                renderPostsGrid(posts, onSelectPost)
              ) : (
                !loading && <Text style={styles.emptySearchText}>No posts found</Text>
              )}
            </View>
          )}
        </ScrollView>
      ) : (
        /* Explore / Browse Mode */
        <>
          {/* Category Pills */}
          <View style={styles.categoriesWrapper}>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.categoryScroll}
            >
              {CATEGORIES.map((cat) => {
                const isSelected = selectedCategory === cat;
                return (
                  <Pressable
                    key={cat}
                    onPress={() => setSelectedCategory(cat)}
                    style={[styles.pill, isSelected && styles.activePill]}
                  >
                    <Text style={[styles.pillText, isSelected && styles.activePillText]}>
                      {cat}
                    </Text>
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>

          {/* 3-Column Explore Grid */}
          <FlatList
            data={explorePosts}
            keyExtractor={(item) => item.id}
            numColumns={3}
            contentContainerStyle={styles.gridContainer}
            renderItem={({ item }) => {
              const media = item.media_url?.[0] || item.media?.[0]?.url;
              return (
                <Pressable
                  onPress={() => onSelectPost && onSelectPost(item)}
                  style={styles.gridItem}
                >
                  {media ? (
                    <Image source={{ uri: media }} style={styles.gridImage} resizeMode="cover" />
                  ) : (
                    <View style={styles.gridPlaceholder}>
                      <Ionicons name="sparkles" size={20} color={colors.primary} />
                      <Text style={styles.gridCaption} numberOfLines={2}>
                        {item.caption || "Vibely"}
                      </Text>
                    </View>
                  )}
                  {(item.likes_count ?? item.likes ?? 0) > 0 && (
                    <View style={styles.gridOverlay}>
                      <Ionicons name="heart" size={11} color="#ffffff" />
                      <Text style={styles.gridOverlayText}>
                        {item.likes_count ?? item.likes}
                      </Text>
                    </View>
                  )}
                </Pressable>
              );
            }}
            ListEmptyComponent={
              <View style={styles.emptyGrid}>
                <Ionicons name="compass-outline" size={48} color={colors.textDim} />
                <Text style={styles.emptyGridText}>No explore items yet</Text>
              </View>
            }
          />
        </>
      )}
    </View>
  );
}

function renderUserRow(
  item: UserSearchResult,
  toggleFollow: (person: UserSearchResult) => void,
) {
  const isFollowing = item.is_following;
  const followsYou = item.follows_you;

  let buttonLabel = "Follow";
  if (isFollowing) {
    buttonLabel = "Following";
  } else if (followsYou) {
    buttonLabel = "Follow Back";
  }

  return (
    <View key={item.personnel_id} style={styles.personRow}>
      <View style={styles.avatar}>
        <Text style={styles.avatarInitial}>
          {(item.display_name || item.user_name).slice(0, 2).toUpperCase()}
        </Text>
      </View>
      <View style={styles.personMeta}>
        <View style={styles.nameRow}>
          <Text style={styles.personName}>{item.display_name || item.user_name}</Text>
        </View>
        <Text style={styles.personHandle}>@{item.user_name}</Text>
        {item.bio ? (
          <Text style={styles.personBio} numberOfLines={1}>
            {item.bio}
          </Text>
        ) : null}
      </View>
      <Pressable
        onPress={() => toggleFollow(item)}
        style={[
          styles.followBtn,
          isFollowing && styles.followingBtn,
          !isFollowing && followsYou && styles.followBackBtn,
        ]}
      >
        <Text
          style={[
            styles.followBtnText,
            isFollowing && styles.followingBtnText,
            !isFollowing && followsYou && styles.followBackBtnText,
          ]}
        >
          {buttonLabel}
        </Text>
      </Pressable>
    </View>
  );
}

function renderHashtagRow(
  item: HashtagSearchResult,
  onPress: (tag: string) => void,
) {
  return (
    <Pressable
      key={item.id || item.name}
      onPress={() => onPress(item.name)}
      style={styles.hashtagRow}
    >
      <View style={styles.hashtagIcon}>
        <Ionicons name="pricetag-outline" size={18} color={colors.cyan} />
      </View>
      <View style={styles.hashtagMeta}>
        <Text style={styles.hashtagName}>#{item.name}</Text>
        <Text style={styles.hashtagCount}>
          {item.post_count} {item.post_count === 1 ? "post" : "posts"}
        </Text>
      </View>
      <Ionicons name="chevron-forward" size={18} color={colors.textDim} />
    </Pressable>
  );
}

function renderPostsGrid(posts: Post[], onSelect?: (p: Post) => void) {
  return (
    <View style={styles.postsGridWrapper}>
      {posts.map((item) => {
        const media = item.media_url?.[0] || item.media?.[0]?.url;
        return (
          <Pressable
            key={item.id}
            onPress={() => onSelect && onSelect(item)}
            style={styles.gridItem}
          >
            {media ? (
              <Image source={{ uri: media }} style={styles.gridImage} resizeMode="cover" />
            ) : (
              <View style={styles.gridPlaceholder}>
                <Ionicons name="image-outline" size={20} color={colors.primary} />
                <Text style={styles.gridCaption} numberOfLines={2}>
                  {item.caption || "Vibely"}
                </Text>
              </View>
            )}
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: colors.canvas,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.cardElevated,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 40,
    gap: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  searchInput: {
    flex: 1,
    color: colors.text,
    fontSize: 14,
    height: "100%",
  },
  searchTabs: {
    flexDirection: "row",
    backgroundColor: colors.canvas,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  searchTabItem: {
    flex: 1,
    paddingVertical: 10,
    alignItems: "center",
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },
  searchTabActive: {
    borderBottomColor: colors.cyan,
  },
  searchTabText: {
    color: colors.textDim,
    fontSize: 13,
    fontWeight: "600",
  },
  searchTabActiveText: {
    color: colors.text,
    fontWeight: "700",
  },
  loadingBar: {
    paddingVertical: 8,
    alignItems: "center",
  },
  scrollContent: {
    padding: 12,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 20,
  },
  sectionHeader: {
    color: colors.textMuted,
    fontSize: 12,
    fontWeight: "700",
    textTransform: "uppercase",
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  categoriesWrapper: {
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  categoryScroll: {
    paddingHorizontal: 12,
    gap: 8,
  },
  pill: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
  },
  activePill: {
    backgroundColor: colors.primary,
    borderColor: colors.cyan,
  },
  pillText: {
    color: colors.textMuted,
    fontSize: 12,
    fontWeight: "600",
  },
  activePillText: {
    color: "#ffffff",
    fontWeight: "700",
  },
  gridContainer: {
    padding: 1,
  },
  postsGridWrapper: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  gridItem: {
    width: GRID_ITEM_SIZE,
    height: GRID_ITEM_SIZE,
    margin: 1,
    backgroundColor: colors.card,
    overflow: "hidden",
    position: "relative",
  },
  gridImage: {
    width: "100%",
    height: "100%",
  },
  gridOverlay: {
    position: "absolute",
    bottom: 4,
    right: 4,
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    backgroundColor: "rgba(0,0,0,0.6)",
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: 6,
  },
  gridOverlayText: {
    color: "#ffffff",
    fontSize: 10,
    fontWeight: "700",
  },
  gridPlaceholder: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 6,
    gap: 6,
    backgroundColor: colors.cardSubtle,
  },
  gridCaption: {
    color: colors.textMuted,
    fontSize: 10,
    textAlign: "center",
  },
  emptyGrid: {
    padding: 40,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  emptyGridText: {
    color: colors.textDim,
    fontSize: 14,
  },
  personRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    gap: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.cardElevated,
    borderWidth: 1.5,
    borderColor: colors.cyan,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarInitial: {
    color: colors.cyan,
    fontSize: 14,
    fontWeight: "700",
  },
  personMeta: {
    flex: 1,
  },
  nameRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  personName: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "700",
  },
  personHandle: {
    color: colors.textDim,
    fontSize: 12,
    marginTop: 1,
  },
  personBio: {
    color: colors.textMuted,
    fontSize: 11,
    marginTop: 2,
  },
  followBtn: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 7,
    borderRadius: 8,
  },
  followBackBtn: {
    backgroundColor: colors.cyan,
  },
  followingBtn: {
    backgroundColor: colors.cardElevated,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  followBtnText: {
    color: "#ffffff",
    fontSize: 12,
    fontWeight: "700",
  },
  followBackBtnText: {
    color: "#05070d",
  },
  followingBtnText: {
    color: colors.textMuted,
  },
  hashtagRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    gap: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  hashtagIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.cardElevated,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: colors.border,
  },
  hashtagMeta: {
    flex: 1,
  },
  hashtagName: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "700",
  },
  hashtagCount: {
    color: colors.textDim,
    fontSize: 12,
    marginTop: 2,
  },
  emptySearchText: {
    color: colors.textDim,
    textAlign: "center",
    paddingTop: 32,
    fontSize: 13,
  },
});
