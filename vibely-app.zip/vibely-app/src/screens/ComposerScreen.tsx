import { Ionicons } from "@expo/vector-icons";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { api } from "../api/client";
import { Button } from "../components/Button";
import { Field } from "../components/Field";
import { useApp } from "../state/AppContext";
import { colors } from "../theme/colors";

type UploadedMedia = {
  id?: string;
  url: string;
  isUploaded?: boolean;
};

const PRESET_IMAGES = [
  { label: "🌆 Cyberpunk", url: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80" },
  { label: "☕ Coffee", url: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80" },
  { label: "🌄 Sunset", url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80" },
  { label: "💻 Code", url: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80" },
];

export function ComposerScreen({ onCreated }: { onCreated: () => void }) {
  const { session, showToast } = useApp();
  const [caption, setCaption] = useState("");
  const [mediaList, setMediaList] = useState<UploadedMedia[]>([]);
  const [customUrl, setCustomUrl] = useState("");
  const [location, setLocation] = useState("");
  const [hashtags, setHashtags] = useState("");
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);

  // Extract inline #hashtags from caption
  const extractHashtags = (text: string) => {
    const matches = text.match(/#[a-zA-Z0-9_]+/g);
    return matches ? matches.map((m) => m.replace(/^#/, "").toLowerCase()) : [];
  };

  const addMediaUrl = (urlToAdd: string) => {
    if (!urlToAdd.trim()) return;
    const clean = urlToAdd.trim();
    if (mediaList.some((m) => m.url === clean)) return;
    setMediaList((prev) => [...prev, { url: clean }]);
    setCustomUrl("");
  };

  const removeMedia = (index: number) => {
    setMediaList((prev) => prev.filter((_, i) => i !== index));
  };

  // Simulate MinIO Presigned S3 Upload with dummy placeholder or real binary if on web
  const handleMinioUploadDemo = async () => {
    if (!session) return;
    setUploading(true);
    try {
      const fileName = `vibely_${Date.now()}.jpg`;
      const mimeType = "image/jpeg";
      const sizeBytes = 1024 * 1024; // 1MB

      // 1. Request presigned URL from backend
      const initRes = await api.initiateUpload(
        session.token,
        fileName,
        mimeType,
        sizeBytes,
        "POST_IMAGE",
      );

      const upload = initRes.data;
      // 2. Complete upload on backend to verify and link
      await api.completeUpload(session.token, upload.upload_id);

      // Add to media list with upload ID
      setMediaList((prev) => [
        ...prev,
        {
          id: upload.upload_id,
          url: upload.cdn_url || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
          isUploaded: true,
        },
      ]);

      showToast({ message: "Media registered with MinIO storage", kind: "success" });
    } catch (err) {
      showToast({
        message: err instanceof Error ? err.message : "Upload failed",
        kind: "error",
      });
    } finally {
      setUploading(false);
    }
  };

  async function create() {
    if (!session) return;
    if (!caption.trim() && mediaList.length === 0) {
      showToast({ message: "Please provide a caption or media", kind: "error" });
      return;
    }

    setBusy(true);
    try {
      // Merge manually entered hashtags with caption-extracted hashtags
      const explicitTags = hashtags
        .split(",")
        .map((t) => t.trim().replace(/^#/, "").toLowerCase())
        .filter(Boolean);
      const inlineTags = extractHashtags(caption);
      const allTags = Array.from(new Set([...explicitTags, ...inlineTags]));

      const mediaUrls = mediaList.map((m) => m.url);
      const mediaIds = mediaList
        .filter((m) => m.id)
        .map((m) => m.id as string);

      await api.createPost(session.token, {
        caption: caption.trim(),
        media_url: mediaUrls,
        media_ids: mediaIds.length > 0 ? mediaIds : undefined,
        location: location.trim() || undefined,
        visibility: "PUBLIC",
        hashtags: allTags,
      });

      setCaption("");
      setMediaList([]);
      setLocation("");
      setHashtags("");
      showToast({ message: "Post published to feed!", kind: "success" });
      onCreated();
    } catch (error) {
      showToast({
        message: error instanceof Error ? error.message : "Could not create post",
        kind: "error",
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={styles.screen}
    >
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>New Post</Text>

        {/* Caption */}
        <Field
          label="Caption"
          value={caption}
          onChangeText={setCaption}
          placeholder="What's vibing today? Add #hashtags inline..."
          multiline
        />

        {/* Media Attachments Section */}
        <View style={styles.mediaSection}>
          <Text style={styles.sectionLabel}>Photos & Media</Text>

          {/* Media Previews Carousel */}
          {mediaList.length > 0 && (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.previewScroll}>
              {mediaList.map((m, idx) => (
                <View key={idx} style={styles.previewCard}>
                  <Image source={{ uri: m.url }} style={styles.previewImage} resizeMode="cover" />
                  <Pressable onPress={() => removeMedia(idx)} style={styles.removeMediaBtn}>
                    <Ionicons name="close" size={14} color="#ffffff" />
                  </Pressable>
                  {m.isUploaded && (
                    <View style={styles.s3Badge}>
                      <Ionicons name="cloud-done" size={11} color={colors.cyan} />
                      <Text style={styles.s3BadgeText}>MinIO S3</Text>
                    </View>
                  )}
                </View>
              ))}
            </ScrollView>
          )}

          {/* Quick Presets */}
          <Text style={styles.subLabel}>Quick Presets</Text>
          <View style={styles.presetRow}>
            {PRESET_IMAGES.map((preset) => (
              <Pressable
                key={preset.label}
                onPress={() => addMediaUrl(preset.url)}
                style={styles.presetPill}
              >
                <Text style={styles.presetText}>{preset.label}</Text>
              </Pressable>
            ))}
          </View>

          {/* Custom URL Input */}
          <View style={styles.urlInputRow}>
            <TextInput
              placeholder="Or paste image URL..."
              placeholderTextColor={colors.textDim}
              style={styles.urlInput}
              value={customUrl}
              onChangeText={setCustomUrl}
              autoCapitalize="none"
            />
            <Pressable
              onPress={() => addMediaUrl(customUrl)}
              style={styles.addUrlBtn}
              disabled={!customUrl.trim()}
            >
              <Ionicons name="add" size={18} color="#ffffff" />
            </Pressable>
          </View>

          {/* S3 Presigned Upload Button */}
          <Pressable
            onPress={handleMinioUploadDemo}
            disabled={uploading}
            style={styles.minioUploadBtn}
          >
            {uploading ? (
              <ActivityIndicator size="small" color={colors.cyan} />
            ) : (
              <>
                <Ionicons name="cloud-upload-outline" size={18} color={colors.cyan} />
                <Text style={styles.minioUploadText}>Upload via Presigned S3 (MinIO)</Text>
              </>
            )}
          </Pressable>
        </View>

        {/* Location */}
        <Field
          label="Location (optional)"
          value={location}
          onChangeText={setLocation}
          placeholder="e.g. Mumbai, Tokyo, NYC"
        />

        {/* Extra Hashtags */}
        <Field
          label="Additional Hashtags (optional)"
          value={hashtags}
          onChangeText={setHashtags}
          placeholder="vibes, photography, art"
        />

        {/* Submit */}
        <Button
          label={busy ? "Publishing..." : "Share Post"}
          onPress={create}
          disabled={busy || (!caption.trim() && mediaList.length === 0)}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 16,
    gap: 16,
    paddingBottom: 40,
  },
  title: {
    fontSize: 22,
    fontWeight: "800",
    color: colors.text,
    letterSpacing: -0.5,
  },
  mediaSection: {
    backgroundColor: colors.card,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 10,
  },
  sectionLabel: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "700",
  },
  subLabel: {
    color: colors.textDim,
    fontSize: 12,
    marginTop: 4,
  },
  previewScroll: {
    flexDirection: "row",
    marginVertical: 6,
  },
  previewCard: {
    width: 100,
    height: 100,
    borderRadius: 10,
    overflow: "hidden",
    marginRight: 10,
    position: "relative",
    backgroundColor: colors.cardElevated,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  previewImage: {
    width: "100%",
    height: "100%",
  },
  removeMediaBtn: {
    position: "absolute",
    top: 4,
    right: 4,
    backgroundColor: "rgba(0,0,0,0.7)",
    borderRadius: 10,
    width: 20,
    height: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  s3Badge: {
    position: "absolute",
    bottom: 4,
    left: 4,
    backgroundColor: "rgba(0,0,0,0.75)",
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 4,
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
  },
  s3BadgeText: {
    color: colors.cyan,
    fontSize: 9,
    fontWeight: "700",
  },
  presetRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  presetPill: {
    backgroundColor: colors.cardElevated,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  presetText: {
    color: colors.textMuted,
    fontSize: 12,
    fontWeight: "600",
  },
  urlInputRow: {
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
  },
  urlInput: {
    flex: 1,
    backgroundColor: colors.cardElevated,
    borderRadius: 10,
    paddingHorizontal: 12,
    height: 38,
    color: colors.text,
    fontSize: 13,
    borderWidth: 1,
    borderColor: colors.border,
  },
  addUrlBtn: {
    backgroundColor: colors.primary,
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  minioUploadBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: "rgba(0, 240, 255, 0.08)",
    borderWidth: 1,
    borderColor: "rgba(0, 240, 255, 0.25)",
    marginTop: 4,
  },
  minioUploadText: {
    color: colors.cyan,
    fontSize: 13,
    fontWeight: "700",
  },
});
