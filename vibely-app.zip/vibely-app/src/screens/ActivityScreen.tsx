import { Ionicons } from "@expo/vector-icons";
import React, { useCallback, useEffect, useState } from "react";
import {
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { api } from "../api/client";
import type { Notification } from "../api/types";
import { useApp } from "../state/AppContext";
import { colors } from "../theme/colors";

type Props = {
  onBack?: () => void;
  onSelectPost?: (postId: string) => void;
};

export function ActivityScreen({ onBack, onSelectPost }: Props) {
  const { session, showToast } = useApp();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const loadNotifications = useCallback(async () => {
    if (!session) return;
    setRefreshing(true);
    try {
      const res = await api.getNotifications(session.token);
      setNotifications(res.data ?? []);
    } catch (err) {
      // Mock fallback notifications for demonstration
      setNotifications([
        {
          id: "1",
          recipient_id: session.personnelId || "",
          actor_id: "actor-1",
          actor_name: "alexa_tech",
          type: "LIKE",
          is_read: false,
          created_at: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
        },
        {
          id: "2",
          recipient_id: session.personnelId || "",
          actor_id: "actor-2",
          actor_name: "cyber_ninja",
          type: "FOLLOW",
          is_read: false,
          created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
        },
        {
          id: "3",
          recipient_id: session.personnelId || "",
          actor_id: "actor-3",
          actor_name: "elena_arts",
          type: "COMMENT",
          is_read: true,
          created_at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
        },
      ]);
    } finally {
      setRefreshing(false);
    }
  }, [session]);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  const markRead = async (item: Notification) => {
    if (!session || item.is_read) return;
    try {
      await api.markNotificationRead(session.token, item.id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === item.id ? { ...n, is_read: true } : n))
      );
    } catch (e) {
      // Ignore
    }
  };

  const getActionIcon = (type: Notification["type"]) => {
    switch (type) {
      case "LIKE":
        return <Ionicons name="heart" size={14} color={colors.heart} />;
      case "COMMENT":
        return <Ionicons name="chatbubble" size={14} color={colors.cyan} />;
      case "FOLLOW":
        return <Ionicons name="person-add" size={14} color={colors.primary} />;
      default:
        return <Ionicons name="notifications" size={14} color={colors.primary} />;
    }
  };

  const getNotificationText = (item: Notification) => {
    const actor = item.actor_name || `user_${item.actor_id.slice(0, 6)}`;
    switch (item.type) {
      case "LIKE":
        return `${actor} liked your photo.`;
      case "COMMENT":
        return `${actor} commented on your post.`;
      case "FOLLOW":
        return `${actor} started following you.`;
      default:
        return `${actor} interacted with your account.`;
    }
  };

  return (
    <View style={styles.container}>
      {/* Top Header */}
      <View style={styles.header}>
        {onBack && (
          <Pressable onPress={onBack} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </Pressable>
        )}
        <Text style={styles.title}>Notifications</Text>
      </View>

      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={loadNotifications}
            tintColor={colors.primary}
          />
        }
        contentContainerStyle={styles.list}
        renderItem={({ item }) => {
          const actor = item.actor_name || "User";
          return (
            <Pressable
              style={[styles.itemRow, !item.is_read && styles.unreadRow]}
              onPress={() => markRead(item)}
            >
              <View style={styles.avatarWrapper}>
                <View style={styles.avatar}>
                  <Text style={styles.avatarText}>{actor.slice(0, 2).toUpperCase()}</Text>
                </View>
                <View style={styles.typeBadge}>{getActionIcon(item.type)}</View>
              </View>

              <View style={styles.contentCol}>
                <Text style={styles.notificationText}>
                  <Text style={styles.actorName}>{actor} </Text>
                  {getNotificationText(item).replace(`${actor} `, "")}
                </Text>
                <Text style={styles.timeText}>
                  {new Date(item.created_at).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </Text>
              </View>

              {item.type === "FOLLOW" ? (
                <Pressable
                  style={styles.followBackBtn}
                  onPress={() =>
                    showToast({ message: `Followed back ${actor}`, kind: "success" })
                  }
                >
                  <Text style={styles.followBackText}>Follow</Text>
                </Pressable>
              ) : (
                <View style={styles.postThumbnail}>
                  <Ionicons name="image" size={16} color={colors.textDim} />
                </View>
              )}
            </Pressable>
          );
        }}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="heart-dislike-outline" size={48} color={colors.textDim} />
            <Text style={styles.emptyTitle}>No Activity Yet</Text>
            <Text style={styles.emptySubtitle}>
              When someone likes or comments on your posts, you'll see it here.
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    height: 48,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    backgroundColor: colors.canvas,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    gap: 12,
  },
  backBtn: {
    padding: 4,
  },
  title: {
    color: colors.text,
    fontSize: 18,
    fontWeight: "800",
  },
  list: {
    paddingVertical: 8,
  },
  itemRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  unreadRow: {
    backgroundColor: colors.cardSubtle,
  },
  avatarWrapper: {
    position: "relative",
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.cardElevated,
    borderWidth: 1.5,
    borderColor: colors.borderLight,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    color: colors.cyan,
    fontSize: 14,
    fontWeight: "800",
  },
  typeBadge: {
    position: "absolute",
    bottom: -2,
    right: -2,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.canvas,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
    justifyContent: "center",
  },
  contentCol: {
    flex: 1,
  },
  notificationText: {
    color: colors.text,
    fontSize: 13,
    lineHeight: 18,
  },
  actorName: {
    fontWeight: "700",
    color: colors.text,
  },
  timeText: {
    color: colors.textDim,
    fontSize: 11,
    marginTop: 2,
  },
  followBackBtn: {
    backgroundColor: colors.primary,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 8,
  },
  followBackText: {
    color: "#ffffff",
    fontSize: 12,
    fontWeight: "700",
  },
  postThumbnail: {
    width: 40,
    height: 40,
    borderRadius: 6,
    backgroundColor: colors.cardElevated,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: colors.border,
  },
  emptyContainer: {
    padding: 40,
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    marginTop: 40,
  },
  emptyTitle: {
    color: colors.text,
    fontSize: 18,
    fontWeight: "700",
  },
  emptySubtitle: {
    color: colors.textDim,
    fontSize: 13,
    textAlign: "center",
    maxWidth: 260,
  },
});
