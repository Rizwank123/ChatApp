import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { api, apiConfig } from "../api/client";
import { readJwtClaims } from "../api/jwt";
import { Button } from "../components/Button";
import { Field } from "../components/Field";
import { useApp } from "../state/AppContext";
import { colors } from "../theme/colors";

export function AuthScreen() {
  const { setSession, showToast } = useApp();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  // Username validation & availability state
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [usernameStatus, setUsernameStatus] = useState<{
    checked: boolean;
    available: boolean;
    reason?: string;
  } | null>(null);
  const debounceTimer = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (mode !== "register" || !userName.trim()) {
      setUsernameStatus(null);
      setCheckingUsername(false);
      return;
    }

    const clean = userName.trim().toLowerCase();
    if (clean.length < 3) {
      setUsernameStatus({
        checked: true,
        available: false,
        reason: "Username must be at least 3 characters",
      });
      return;
    }

    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }

    setCheckingUsername(true);
    debounceTimer.current = setTimeout(async () => {
      try {
        const res = await api.checkUsername(clean);
        setUsernameStatus({
          checked: true,
          available: res.data.is_available,
          reason: res.data.reason,
        });
      } catch (err: any) {
        setUsernameStatus({
          checked: true,
          available: false,
          reason: err?.message || "Error validating username",
        });
      } finally {
        setCheckingUsername(false);
      }
    }, 400);

    return () => {
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current);
      }
    };
  }, [userName, mode]);

  async function submit() {
    setBusy(true);
    try {
      const cleanUsername = userName.trim().toLowerCase();
      if (mode === "register") {
        if (usernameStatus && !usernameStatus.available) {
          showToast({ message: usernameStatus.reason || "Username is unavailable", kind: "error" });
          setBusy(false);
          return;
        }
        await api.register({
          first_name: firstName,
          last_name: lastName,
          user_name: cleanUsername,
          role: "USER",
          password,
        });
        showToast({ message: "Account created. Signing you in.", kind: "success" });
      }
      const result = await api.login({ username: cleanUsername, password });
      const claims = readJwtClaims(result.data.token);
      setSession({
        token: result.data.token,
        expiresIn: result.data.expires_in,
        userName: cleanUsername,
        personnelId: claims.personnel_id,
      });
    } catch (error) {
      showToast({
        message: error instanceof Error ? error.message : "Authentication failed",
        kind: "error",
      });
    } finally {
      setBusy(false);
    }
  }

  const isSubmitDisabled =
    busy ||
    !userName.trim() ||
    !password ||
    (mode === "register" && (checkingUsername || (usernameStatus !== null && !usernameStatus.available)));

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={styles.screen}
    >
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.brandBlock}>
          <Text style={styles.logo}>Vibely</Text>
          <Text style={styles.tagline}>Social posts, friends, and realtime chat.</Text>
        </View>

        <View style={styles.panel}>
          <View style={styles.switcher}>
            <Button
              label="Login"
              variant={mode === "login" ? "primary" : "secondary"}
              onPress={() => setMode("login")}
              style={styles.switchButton}
            />
            <Button
              label="Register"
              variant={mode === "register" ? "primary" : "secondary"}
              onPress={() => setMode("register")}
              style={styles.switchButton}
            />
          </View>

          {mode === "register" ? (
            <View style={styles.row}>
              <Field
                label="First name"
                value={firstName}
                onChangeText={setFirstName}
                style={styles.half}
              />
              <Field
                label="Last name"
                value={lastName}
                onChangeText={setLastName}
                style={styles.half}
              />
            </View>
          ) : null}

          <View>
            <Field
              label="Username"
              value={userName}
              onChangeText={(text) => setUserName(text.toLowerCase())}
              placeholder={mode === "register" ? "e.g. cyber_samurai" : "username or mobile"}
              autoCapitalize="none"
              autoCorrect={false}
            />
            {mode === "register" && (
              <View style={styles.availabilityRow}>
                {checkingUsername ? (
                  <View style={styles.statusIndicator}>
                    <ActivityIndicator size="small" color={colors.cyan} />
                    <Text style={styles.checkingText}>Checking availability...</Text>
                  </View>
                ) : usernameStatus?.checked ? (
                  <Text
                    style={[
                      styles.statusText,
                      usernameStatus.available ? styles.statusAvailable : styles.statusUnavailable,
                    ]}
                  >
                    {usernameStatus.available
                      ? "✓ Username is available"
                      : `✗ ${usernameStatus.reason || "Username is unavailable"}`}
                  </Text>
                ) : null}
              </View>
            )}
          </View>

          <Field
            label="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            placeholder="password"
          />

          <Button
            label={busy ? "Working..." : mode === "login" ? "Sign in" : "Create account"}
            onPress={submit}
            disabled={isSubmitDisabled}
          />
          <Text style={styles.apiText}>API: {apiConfig.baseUrl}</Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flexGrow: 1,
    justifyContent: "center",
    padding: 22,
    gap: 24,
  },
  brandBlock: {
    gap: 6,
    alignItems: "center",
  },
  logo: {
    fontSize: 44,
    fontWeight: "900",
    color: colors.text,
    letterSpacing: -0.5,
  },
  tagline: {
    color: colors.textDim,
    fontSize: 15,
  },
  panel: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    gap: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  switcher: {
    flexDirection: "row",
    gap: 10,
  },
  switchButton: {
    flex: 1,
  },
  row: {
    flexDirection: "row",
    gap: 10,
  },
  half: {
    flex: 1,
  },
  availabilityRow: {
    marginTop: 6,
    minHeight: 18,
  },
  statusIndicator: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  checkingText: {
    fontSize: 12,
    color: colors.cyan,
  },
  statusText: {
    fontSize: 12,
    fontWeight: "600",
  },
  statusAvailable: {
    color: "#10b981",
  },
  statusUnavailable: {
    color: "#ef4444",
  },
  apiText: {
    color: colors.textDim,
    fontSize: 11,
    textAlign: "center",
    marginTop: 4,
  },
});
