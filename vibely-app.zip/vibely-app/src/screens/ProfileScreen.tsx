import { Ionicons } from "@expo/vector-icons";
import React, { useCallback, useEffect, useState } from "react";
import {
  Dimensions,
  FlatList,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { api } from "../api/client";
import type { Personnel, Post } from "../api/types";
import { useApp } from "../state/AppContext";
import { colors } from "../theme/colors";

const { width } = Dimensions.get("window");
const GRID_SIZE = (width - 4) / 3;

type Tab = "posts" | "saved" | "tagged";

type Props = {
  onSelectPost?: (post: Post) => void;
  onLogout?: () => void;
  onOpenFollowList?: (
    initialTab: "followers" | "following",
    followerCount: number,
    followingCount: number,
  ) => void;
};

export function ProfileScreen({ onSelectPost, onLogout, onOpenFollowList }: Props) {
  const { session, showToast } = useApp();
  const [profile, setProfile] = useState<Personnel>();
  const [posts, setPosts] = useState<Post[]>([]);
  const [activeTab, setActiveTab] = useState<Tab>("posts");
  const [postCount, setPostCount] = useState(0);
  const [followerCount, setFollowerCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);

  const HIGHLIGHTS = [
    { id: "1", title: "Highlights", icon: "sparkles" },
    { id: "2", title: "Travel", icon: "airplane" },
    { id: "3", title: "Art", icon: "color-palette" },
    { id: "4", title: "Code", icon: "terminal" },
  ];

  const loadProfile = useCallback(async () => {
    if (!session?.personnelId) return;
    try {
      const pRes = await api.getPersonnel(session.token, session.personnelId);
      setProfile(pRes.data);

      const postsRes = await api.getUserPosts(session.token, session.personnelId);
      setPosts(postsRes.data ?? []);
      setPostCount(postsRes.total ?? postsRes.data?.length ?? 0);

      const countersRes = await api.getUserCounters(session.token, session.personnelId);
      if (countersRes?.data) {
        setFollowerCount(countersRes.data.follower_count ?? 0);
        setFollowingCount(countersRes.data.following_count ?? 0);
        if (countersRes.data.post_count !== undefined) {
          setPostCount(countersRes.data.post_count);
        }
      }
    } catch (err) {
      // Ignore
    }
  }, [session]);

  useEffect(() => {
    loadProfile();
  }, [loadProfile]);

  const username = session?.userName || "cyber_vibe";
  const displayName = profile?.display_name || (profile?.first_name ? `${profile.first_name} ${profile.last_name || ""}`.trim() : "Vibely User");

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Top Bar */}
      <View style={styles.topBar}>
        <View style={styles.topBarLeft}>
          <Ionicons name="lock-closed" size={14} color={colors.text} />
          <Text style={styles.topUsername}>{username}</Text>
          <Ionicons name="chevron-down" size={14} color={colors.textMuted} />
        </View>

        <View style={styles.topBarRight}>
          <Pressable style={styles.topIcon} onPress={onLogout}>
            <Ionicons name="log-out-outline" size={22} color={colors.danger} />
          </Pressable>
        </View>
      </View>

      {/* Main Profile Header Info */}
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatarGradient}>
            <View style={styles.avatarInner}>
              <Text style={styles.avatarText}>{username.slice(0, 2).toUpperCase()}</Text>
            </View>
          </View>
        </View>

        {/* Stats Row */}
        <View style={styles.statsRow}>
          <View style={styles.statCol}>
            <Text style={styles.statNumber}>{postCount}</Text>
            <Text style={styles.statLabel}>Posts</Text>
          </View>
          <Pressable
            style={styles.statCol}
            onPress={() => onOpenFollowList?.("followers", followerCount, followingCount)}
          >
            <Text style={styles.statNumber}>{followerCount}</Text>
            <Text style={styles.statLabel}>Followers</Text>
          </Pressable>
          <Pressable
            style={styles.statCol}
            onPress={() => onOpenFollowList?.("following", followerCount, followingCount)}
          >
            <Text style={styles.statNumber}>{followingCount}</Text>
            <Text style={styles.statLabel}>Following</Text>
          </Pressable>
        </View>
      </View>

      {/* Bio Section */}
      <View style={styles.bioSection}>
        <Text style={styles.fullName}>{displayName}</Text>
        <Text style={styles.bioHandle}>@{username}</Text>
        <Text style={styles.bioText}>
          ⚡ Building the next generation decentralized feed with hybrid fanout & low latency.
        </Text>
        <Text style={styles.bioLink}>🔗 vibely.network/{username}</Text>
      </View>

      {/* Action Buttons */}
      <View style={styles.buttonRow}>
        <Pressable
          style={styles.actionBtn}
          onPress={() => showToast({ message: "Edit profile coming soon", kind: "info" })}
        >
          <Text style={styles.actionBtnText}>Edit Profile</Text>
        </Pressable>
        <Pressable
          style={styles.actionBtn}
          onPress={() => showToast({ message: "Profile link copied", kind: "success" })}
        >
          <Text style={styles.actionBtnText}>Share Profile</Text>
        </Pressable>
        <Pressable style={styles.iconActionBtn}>
          <Ionicons name="person-add" size={16} color={colors.text} />
        </Pressable>
      </View>

      {/* Story Highlights */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.highlightsContainer}
      >
        {HIGHLIGHTS.map((h) => (
          <View key={h.id} style={styles.highlightCol}>
            <View style={styles.highlightRing}>
              <View style={styles.highlightInner}>
                <Ionicons name={h.icon as any} size={22} color={colors.cyan} />
              </View>
            </View>
            <Text style={styles.highlightText} numberOfLines={1}>
              {h.title}
            </Text>
          </View>
        ))}
      </ScrollView>

      {/* Tabs Row */}
      <View style={styles.tabBar}>
        <Pressable
          style={[styles.tabButton, activeTab === "posts" && styles.activeTab]}
          onPress={() => setActiveTab("posts")}
        >
          <Ionicons
            name="grid-outline"
            size={22}
            color={activeTab === "posts" ? colors.cyan : colors.textDim}
          />
        </Pressable>
        <Pressable
          style={[styles.tabButton, activeTab === "saved" && styles.activeTab]}
          onPress={() => setActiveTab("saved")}
        >
          <Ionicons
            name="bookmark-outline"
            size={22}
            color={activeTab === "saved" ? colors.cyan : colors.textDim}
          />
        </Pressable>
        <Pressable
          style={[styles.tabButton, activeTab === "tagged" && styles.activeTab]}
          onPress={() => setActiveTab("tagged")}
        >
          <Ionicons
            name="person-circle-outline"
            size={22}
            color={activeTab === "tagged" ? colors.cyan : colors.textDim}
          />
        </Pressable>
      </View>

      {/* Post Grid */}
      <View style={styles.gridContainer}>
        {posts.map((post) => {
          const media = post.media_url?.[0];
          return (
            <Pressable
              key={post.id}
              onPress={() => onSelectPost && onSelectPost(post)}
              style={styles.gridItem}
            >
              {media ? (
                <Image source={{ uri: media }} style={styles.gridMedia} resizeMode="cover" />
              ) : (
                <View style={styles.gridPlaceholder}>
                  <Ionicons name="image-outline" size={20} color={colors.textDim} />
                  <Text style={styles.gridCaption} numberOfLines={2}>
                    {post.caption || "Post"}
                  </Text>
                </View>
              )}
            </Pressable>
          );
        })}
        {posts.length === 0 && (
          <View style={styles.emptyGrid}>
            <Ionicons name="camera-outline" size={48} color={colors.textDim} />
            <Text style={styles.emptyText}>No posts yet</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  topBar: {
    height: 48,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.canvas,
  },
  topBarLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  topUsername: {
    color: colors.text,
    fontSize: 18,
    fontWeight: "800",
  },
  topBarRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  topIcon: {
    padding: 4,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
    gap: 24,
  },
  avatarContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
  avatarGradient: {
    width: 82,
    height: 82,
    borderRadius: 41,
    backgroundColor: colors.primary,
    borderWidth: 2,
    borderColor: colors.cyan,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarInner: {
    width: 74,
    height: 74,
    borderRadius: 37,
    backgroundColor: colors.cardElevated,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    color: colors.cyan,
    fontSize: 24,
    fontWeight: "900",
  },
  statsRow: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
  },
  statCol: {
    alignItems: "center",
    gap: 2,
  },
  statNumber: {
    color: colors.text,
    fontSize: 18,
    fontWeight: "800",
  },
  statLabel: {
    color: colors.textMuted,
    fontSize: 12,
  },
  bioSection: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 4,
  },
  fullName: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "700",
  },
  bioHandle: {
    color: colors.cyan,
    fontSize: 12,
    fontWeight: "600",
  },
  bioText: {
    color: colors.textMuted,
    fontSize: 13,
    lineHeight: 18,
  },
  bioLink: {
    color: colors.cyan,
    fontSize: 13,
    fontWeight: "600",
    marginTop: 2,
  },
  buttonRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 8,
  },
  actionBtn: {
    flex: 1,
    backgroundColor: colors.cardElevated,
    borderRadius: 8,
    paddingVertical: 8,
    alignItems: "center",
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  actionBtnText: {
    color: colors.text,
    fontSize: 13,
    fontWeight: "700",
  },
  iconActionBtn: {
    backgroundColor: colors.cardElevated,
    borderRadius: 8,
    width: 36,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  highlightsContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 16,
  },
  highlightCol: {
    alignItems: "center",
    gap: 6,
    width: 64,
  },
  highlightRing: {
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 1.5,
    borderColor: colors.borderLight,
    alignItems: "center",
    justifyContent: "center",
  },
  highlightInner: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: colors.cardElevated,
    alignItems: "center",
    justifyContent: "center",
  },
  highlightText: {
    color: colors.textMuted,
    fontSize: 11,
    textAlign: "center",
  },
  tabBar: {
    flexDirection: "row",
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.canvas,
  },
  tabButton: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 10,
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },
  activeTab: {
    borderBottomColor: colors.cyan,
  },
  gridContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    padding: 1,
  },
  gridItem: {
    width: GRID_SIZE,
    height: GRID_SIZE,
    margin: 1,
    backgroundColor: colors.card,
  },
  gridMedia: {
    width: "100%",
    height: "100%",
  },
  gridPlaceholder: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.cardSubtle,
    padding: 6,
    gap: 4,
  },
  gridCaption: {
    color: colors.textDim,
    fontSize: 10,
    textAlign: "center",
  },
  emptyGrid: {
    width: "100%",
    paddingVertical: 48,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  emptyText: {
    color: colors.textDim,
    fontSize: 14,
  },
});
