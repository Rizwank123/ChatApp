import React, { useCallback, useEffect, useState } from "react";
import { FlatList, RefreshControl, StyleSheet, Text, View } from "react-native";

import { api } from "../api/client";
import type { Post } from "../api/types";
import { PostCard } from "../components/PostCard";
import { StoriesTray, StoryItem } from "../components/StoriesTray";
import { useApp } from "../state/AppContext";
import { colors } from "../theme/colors";

type Props = {
  onOpenComments: (post: Post) => void;
  onOpenCreateStory?: () => void;
};

export function FeedScreen({ onOpenComments, onOpenCreateStory }: Props) {
  const { session, posts, setPosts, showToast } = useApp();
  const [refreshing, setRefreshing] = useState(false);

  // Mock initial stories tray (with current user first)
  const stories: StoryItem[] = [
    { id: "user", username: "You", isUser: true },
    { id: "1", username: "alexa", hasUnseen: true },
    { id: "2", username: "marcus_dev", hasUnseen: true },
    { id: "3", username: "neon_vibes", hasUnseen: false },
    { id: "4", username: "elena_arts", hasUnseen: true },
    { id: "5", username: "crypto_wolf", hasUnseen: false },
  ];

  const load = useCallback(async () => {
    if (!session) {
      return;
    }
    setRefreshing(true);
    try {
      const result = await api.getFeed(session.token);
      setPosts(result.data ?? []);
    } catch (error) {
      showToast({
        message: error instanceof Error ? error.message : "Could not load feed",
        kind: "error",
      });
    } finally {
      setRefreshing(false);
    }
  }, [session, setPosts, showToast]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleLike(post: Post) {
    if (!session) return;
    try {
      await api.likePost(session.token, post.id);
    } catch (e) {
      // Handled in optimistic UI
    }
  }

  async function handleUnlike(post: Post) {
    if (!session) return;
    try {
      await api.unlikePost(session.token, post.id);
    } catch (e) {
      // Handled in optimistic UI
    }
  }

  async function handleSave(post: Post) {
    if (!session) return;
    try {
      await api.savePost(session.token, post.id);
      showToast({ message: "Post saved to your bookmarks", kind: "success" });
    } catch (error) {
      showToast({ message: "Could not save post", kind: "error" });
    }
  }

  async function handleBlock(creatorId: string) {
    if (!session) return;
    try {
      await api.blockUser(session.token, creatorId);
      showToast({ message: "User blocked", kind: "success" });
      load();
    } catch (error) {
      showToast({ message: "Could not block user", kind: "error" });
    }
  }

  async function handleShare(post: Post) {
    if (!session) return;
    try {
      await api.recordPostShare(session.token, post.id);
      showToast({ message: "Link copied & shared!", kind: "success" });
    } catch {
      showToast({ message: "Post shared", kind: "info" });
    }
  }

  return (
    <View style={styles.container}>
      <FlatList
        contentContainerStyle={styles.list}
        data={posts}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={load}
            tintColor={colors.primary}
            colors={[colors.primary]}
          />
        }
        ListHeaderComponent={
          <StoriesTray
            stories={stories}
            onAddStory={onOpenCreateStory}
            onSelectStory={(s) =>
              showToast({ message: `Viewing ${s.username}'s story`, kind: "info" })
            }
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyTitle}>Welcome to your Feed</Text>
            <Text style={styles.emptySubtitle}>
              Follow friends or discover creators in Explore to see photos and videos here.
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <PostCard
            post={item}
            onLike={handleLike}
            onUnlike={handleUnlike}
            onComments={onOpenComments}
            onSave={handleSave}
            onShare={handleShare}
            onBlockCreator={handleBlock}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  list: {
    paddingBottom: 24,
  },
  emptyContainer: {
    padding: 32,
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    marginTop: 40,
  },
  emptyTitle: {
    color: colors.text,
    fontSize: 18,
    fontWeight: "700",
    textAlign: "center",
  },
  emptySubtitle: {
    color: colors.textDim,
    fontSize: 13,
    textAlign: "center",
    lineHeight: 20,
    maxWidth: 280,
  },
});
