export const colors = {
  // Midnight Cyber core palette
  background: "#080c14",
  canvas: "#0a0e17",
  card: "#121927",
  cardElevated: "#1a2336",
  cardSubtle: "#0f1623",
  border: "#1e293b",
  borderLight: "#334155",
  
  // High-contrast typography
  text: "#f8fafc",
  textMuted: "#94a3b8",
  textDim: "#64748b",
  
  // Distinctive Cyber Accents
  primary: "#8b5cf6",       // Radiant Cyber Violet
  primaryHover: "#7c3aed",
  cyan: "#06b6d4",          // Electric Cyan (story ring / live)
  heart: "#f43f5e",         // Neon Rose for Likes
  bookmark: "#f59e0b",      // Cyber Amber for Bookmarks
  emerald: "#10b981",       // Connected / Success
  danger: "#ef4444",        // Destructive / Unfollow
  
  // Gradients for stories and badges
  storyGradient: ["#8b5cf6", "#d946ef", "#06b6d4"] as const,

  // Compatibility aliases for existing components
  ink: "#f8fafc",
  muted: "#94a3b8",
  soft: "#121927",
  line: "#1e293b",
  surface: "#121927",
  coral: "#f43f5e",
  jade: "#10b981",
  violet: "#8b5cf6",
  amber: "#f59e0b",
  navy: "#0a0e17",
};
