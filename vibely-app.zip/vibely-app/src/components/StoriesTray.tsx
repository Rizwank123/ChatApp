import { Ionicons } from "@expo/vector-icons";
import React from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";

import { colors } from "../theme/colors";

export type StoryItem = {
  id: string;
  username: string;
  isUser?: boolean;
  hasUnseen?: boolean;
};

type Props = {
  stories: StoryItem[];
  onSelectStory?: (story: StoryItem) => void;
  onAddStory?: () => void;
};

export function StoriesTray({ stories, onSelectStory, onAddStory }: Props) {
  return (
    <View style={styles.container}>
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.list}
        data={stories}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          if (item.isUser) {
            return (
              <Pressable style={styles.storyCol} onPress={onAddStory}>
                <View style={styles.userRing}>
                  <View style={styles.avatarInner}>
                    <Ionicons name="person" size={20} color={colors.textMuted} />
                  </View>
                  <View style={styles.addBadge}>
                    <Ionicons name="add" size={14} color="#ffffff" />
                  </View>
                </View>
                <Text style={styles.storyName} numberOfLines={1}>
                  Your Story
                </Text>
              </Pressable>
            );
          }

          return (
            <Pressable
              style={styles.storyCol}
              onPress={() => onSelectStory && onSelectStory(item)}
            >
              <View
                style={[
                  styles.storyRing,
                  item.hasUnseen ? styles.activeRing : styles.seenRing,
                ]}
              >
                <View style={styles.avatarInner}>
                  <Text style={styles.avatarInitial}>
                    {item.username.slice(0, 2).toUpperCase()}
                  </Text>
                </View>
              </View>
              <Text style={styles.storyName} numberOfLines={1}>
                {item.username}
              </Text>
            </Pressable>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.canvas,
  },
  list: {
    paddingHorizontal: 12,
    gap: 14,
  },
  storyCol: {
    alignItems: "center",
    width: 68,
    gap: 5,
  },
  storyRing: {
    width: 64,
    height: 64,
    borderRadius: 32,
    padding: 2.5,
    alignItems: "center",
    justifyContent: "center",
  },
  activeRing: {
    backgroundColor: colors.primary,
    borderWidth: 2,
    borderColor: colors.cyan,
  },
  seenRing: {
    backgroundColor: colors.border,
  },
  userRing: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 1.5,
    borderColor: colors.borderLight,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  avatarInner: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.cardElevated,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarInitial: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "700",
  },
  addBadge: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.primary,
    borderWidth: 2,
    borderColor: colors.canvas,
    alignItems: "center",
    justifyContent: "center",
  },
  storyName: {
    color: colors.textMuted,
    fontSize: 11,
    fontWeight: "500",
    textAlign: "center",
  },
});
