import { Ionicons } from "@expo/vector-icons";
import React, { useRef, useState } from "react";
import {
  Animated,
  Dimensions,
  Image,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import type { Post } from "../api/types";
import { colors } from "../theme/colors";

const { width } = Dimensions.get("window");

type Props = {
  post: Post;
  onLike: (post: Post) => void;
  onUnlike: (post: Post) => void;
  onComments: (post: Post) => void;
  onSave?: (post: Post) => void;
  onShare?: (post: Post) => void;
  onDelete?: (post: Post) => void;
  onBlockCreator?: (creatorId: string) => void;
};

export function PostCard({
  post,
  onLike,
  onUnlike,
  onComments,
  onSave,
  onShare,
  onDelete,
  onBlockCreator,
}: Props) {
  const [isLiked, setIsLiked] = useState(post.is_liked ?? false);
  const [isSaved, setIsSaved] = useState(post.is_saved ?? false);
  const [likeCount, setLikeCount] = useState(post.likes_count ?? post.likes ?? 0);
  const [menuVisible, setMenuVisible] = useState(false);
  const [showHeartAnim, setShowHeartAnim] = useState(false);
  const [activeMediaIndex, setActiveMediaIndex] = useState(0);

  const lastTapRef = useRef<number>(0);
  const heartScale = useRef(new Animated.Value(0)).current;
  const heartOpacity = useRef(new Animated.Value(0)).current;

  const allMedia: string[] = post.media && post.media.length > 0
    ? post.media.map((m) => m.url)
    : (post.media_url || []);
  const commentCount = post.comments_count ?? post.comments ?? 0;
  const username = post.creator_name || `user_${post.personnel_id?.slice(0, 6)}`;

  const handleDoubleTap = () => {
    const now = Date.now();
    const DOUBLE_PRESS_DELAY = 300;
    if (now - lastTapRef.current < DOUBLE_PRESS_DELAY) {
      triggerHeartAnimation();
      if (!isLiked) {
        setIsLiked(true);
        setLikeCount((prev) => prev + 1);
        onLike(post);
      }
    }
    lastTapRef.current = now;
  };

  const triggerHeartAnimation = () => {
    setShowHeartAnim(true);
    heartScale.setValue(0.3);
    heartOpacity.setValue(1);

    Animated.parallel([
      Animated.spring(heartScale, {
        toValue: 1.2,
        friction: 3,
        useNativeDriver: true,
      }),
      Animated.timing(heartOpacity, {
        toValue: 0,
        duration: 800,
        delay: 200,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setShowHeartAnim(false);
    });
  };

  const toggleLike = () => {
    if (isLiked) {
      setIsLiked(false);
      setLikeCount((prev) => Math.max(0, prev - 1));
      onUnlike(post);
    } else {
      setIsLiked(true);
      setLikeCount((prev) => prev + 1);
      triggerHeartAnimation();
      onLike(post);
    }
  };

  const toggleSave = () => {
    setIsSaved(!isSaved);
    if (onSave) {
      onSave(post);
    }
  };

  return (
    <View style={styles.card}>
      {/* Instagram Header */}
      <View style={styles.header}>
        <View style={styles.avatarGradient}>
          <View style={styles.avatarInner}>
            <Text style={styles.avatarText}>{username.slice(0, 2).toUpperCase()}</Text>
          </View>
        </View>

        <View style={styles.meta}>
          <Text style={styles.username}>{username}</Text>
          {post.location ? <Text style={styles.location}>{post.location}</Text> : null}
        </View>

        <Pressable onPress={() => setMenuVisible(true)} style={styles.moreButton}>
          <Ionicons name="ellipsis-horizontal" size={18} color={colors.textMuted} />
        </Pressable>
      </View>

      {/* Media Carousel with Double-Tap to Like */}
      <View style={styles.mediaContainer}>
        {allMedia.length > 1 ? (
          <View>
            <Animated.ScrollView
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              onMomentumScrollEnd={(e) => {
                const newIndex = Math.round(e.nativeEvent.contentOffset.x / width);
                setActiveMediaIndex(newIndex);
              }}
            >
              {allMedia.map((mUrl, index) => (
                <Pressable
                  key={index}
                  onPress={handleDoubleTap}
                  style={{ width, height: width }}
                >
                  <Image source={{ uri: mUrl }} style={styles.media} resizeMode="cover" />
                </Pressable>
              ))}
            </Animated.ScrollView>
            {/* Carousel Pagination Dots */}
            <View style={styles.paginationRow}>
              {allMedia.map((_, i) => (
                <View
                  key={i}
                  style={[
                    styles.paginationDot,
                    activeMediaIndex === i && styles.paginationDotActive,
                  ]}
                />
              ))}
            </View>
          </View>
        ) : (
          <Pressable onPress={handleDoubleTap} style={{ width, height: width }}>
            {allMedia.length === 1 ? (
              <Image source={{ uri: allMedia[0] }} style={styles.media} resizeMode="cover" />
            ) : (
              <View style={styles.placeholderMedia}>
                <Ionicons name="image-outline" size={48} color={colors.borderLight} />
                <Text style={styles.placeholderText}>Vibely Post</Text>
              </View>
            )}
          </Pressable>
        )}

        {/* Animated Pop Heart */}
        {showHeartAnim && (
          <Animated.View
            style={[
              styles.popHeart,
              {
                opacity: heartOpacity,
                transform: [{ scale: heartScale }],
              },
            ]}
          >
            <Ionicons name="heart" size={90} color={colors.heart} />
          </Animated.View>
        )}
      </View>

      {/* Action Row */}
      <View style={styles.actionBar}>
        <View style={styles.leftActions}>
          <Pressable onPress={toggleLike} style={styles.iconButton}>
            <Ionicons
              name={isLiked ? "heart" : "heart-outline"}
              size={26}
              color={isLiked ? colors.heart : colors.text}
            />
          </Pressable>

          <Pressable onPress={() => onComments(post)} style={styles.iconButton}>
            <Ionicons name="chatbubble-outline" size={24} color={colors.text} />
          </Pressable>

          <Pressable
            onPress={() => onShare && onShare(post)}
            style={styles.iconButton}
          >
            <Ionicons name="paper-plane-outline" size={24} color={colors.text} />
          </Pressable>
        </View>

        <Pressable onPress={toggleSave} style={styles.iconButton}>
          <Ionicons
            name={isSaved ? "bookmark" : "bookmark-outline"}
            size={24}
            color={isSaved ? colors.bookmark : colors.text}
          />
        </Pressable>
      </View>

      {/* Social Proof (Likes) */}
      <View style={styles.infoSection}>
        <Text style={styles.likeText}>
          {likeCount.toLocaleString()} {likeCount === 1 ? "like" : "likes"}
        </Text>

        {/* Caption */}
        {post.caption ? (
          <View style={styles.captionRow}>
            <Text style={styles.captionText}>
              <Text style={styles.captionUser}>{username} </Text>
              {post.caption}
            </Text>
          </View>
        ) : null}

        {/* Hashtags display */}
        {post.hashtags && post.hashtags.length > 0 && (
          <View style={styles.hashtagsRow}>
            {post.hashtags.map((tag) => (
              <Text key={tag} style={styles.hashtagBadge}>
                #{tag}{" "}
              </Text>
            ))}
          </View>
        )}

        {/* Comments link */}
        {commentCount > 0 ? (
          <Pressable onPress={() => onComments(post)}>
            <Text style={styles.commentsLink}>
              View all {commentCount} {commentCount === 1 ? "comment" : "comments"}
            </Text>
          </Pressable>
        ) : (
          <Pressable onPress={() => onComments(post)}>
            <Text style={styles.commentsLink}>Add a comment...</Text>
          </Pressable>
        )}

        {/* Post Timestamp */}
        <Text style={styles.timestamp}>
          {post.created_at ? new Date(post.created_at).toLocaleDateString() : "Just now"}
        </Text>
      </View>

      {/* Action Options Modal */}
      <Modal visible={menuVisible} transparent animationType="fade">
        <Pressable style={styles.modalOverlay} onPress={() => setMenuVisible(false)}>
          <View style={styles.modalSheet}>
            <View style={styles.sheetHandle} />
            <Pressable
              style={styles.sheetOption}
              onPress={() => {
                setMenuVisible(false);
                toggleSave();
              }}
            >
              <Ionicons
                name={isSaved ? "bookmark" : "bookmark-outline"}
                size={20}
                color={colors.text}
              />
              <Text style={styles.sheetOptionText}>{isSaved ? "Unsave" : "Save"}</Text>
            </Pressable>

            {onDelete ? (
              <Pressable
                style={styles.sheetOption}
                onPress={() => {
                  setMenuVisible(false);
                  onDelete(post);
                }}
              >
                <Ionicons name="trash-outline" size={20} color={colors.danger} />
                <Text style={[styles.sheetOptionText, { color: colors.danger }]}>
                  Delete Post
                </Text>
              </Pressable>
            ) : null}

            {onBlockCreator ? (
              <Pressable
                style={styles.sheetOption}
                onPress={() => {
                  setMenuVisible(false);
                  onBlockCreator(post.personnel_id);
                }}
              >
                <Ionicons name="hand-left-outline" size={20} color={colors.danger} />
                <Text style={[styles.sheetOptionText, { color: colors.danger }]}>
                  Block User
                </Text>
              </Pressable>
            ) : null}

            <Pressable
              style={[styles.sheetOption, styles.cancelOption]}
              onPress={() => setMenuVisible(false)}
            >
              <Text style={styles.cancelText}>Cancel</Text>
            </Pressable>
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 16,
    overflow: "hidden",
  },
  header: {
    height: 54,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    gap: 10,
  },
  avatarGradient: {
    width: 38,
    height: 38,
    borderRadius: 19,
    padding: 2,
    backgroundColor: colors.primary,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarInner: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.canvas,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    color: colors.cyan,
    fontSize: 12,
    fontWeight: "800",
  },
  meta: {
    flex: 1,
  },
  username: {
    color: colors.text,
    fontSize: 13,
    fontWeight: "700",
  },
  location: {
    color: colors.textDim,
    fontSize: 11,
    marginTop: 1,
  },
  moreButton: {
    padding: 6,
  },
  mediaContainer: {
    width: "100%",
    aspectRatio: 1,
    backgroundColor: colors.cardSubtle,
    position: "relative",
    justifyContent: "center",
    alignItems: "center",
  },
  media: {
    width: "100%",
    height: "100%",
  },
  placeholderMedia: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  placeholderText: {
    color: colors.textDim,
    fontSize: 12,
    fontWeight: "600",
  },
  popHeart: {
    position: "absolute",
    alignSelf: "center",
    zIndex: 10,
  },
  actionBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  leftActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },
  iconButton: {
    padding: 2,
  },
  infoSection: {
    paddingHorizontal: 12,
    paddingBottom: 12,
    gap: 5,
  },
  likeText: {
    color: colors.text,
    fontSize: 13,
    fontWeight: "700",
  },
  captionRow: {
    marginTop: 2,
  },
  captionText: {
    color: colors.text,
    fontSize: 13,
    lineHeight: 18,
  },
  captionUser: {
    fontWeight: "700",
    color: colors.text,
  },
  commentsLink: {
    color: colors.textDim,
    fontSize: 12,
    marginTop: 2,
  },
  timestamp: {
    color: colors.textDim,
    fontSize: 10,
    textTransform: "uppercase",
    marginTop: 2,
    letterSpacing: 0.5,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.75)",
    justifyContent: "flex-end",
  },
  modalSheet: {
    backgroundColor: colors.cardElevated,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    borderColor: colors.borderLight,
    padding: 20,
    gap: 14,
  },
  sheetHandle: {
    width: 36,
    height: 4,
    backgroundColor: colors.borderLight,
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 8,
  },
  sheetOption: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingVertical: 12,
  },
  sheetOptionText: {
    color: colors.text,
    fontSize: 15,
    fontWeight: "600",
  },
  cancelOption: {
    justifyContent: "center",
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: 16,
    marginTop: 4,
  },
  cancelText: {
    color: colors.textMuted,
    fontSize: 14,
    fontWeight: "600",
    textAlign: "center",
  },
  paginationRow: {
    position: "absolute",
    bottom: 10,
    alignSelf: "center",
    flexDirection: "row",
    gap: 5,
    backgroundColor: "rgba(0,0,0,0.5)",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },
  paginationDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "rgba(255,255,255,0.4)",
  },
  paginationDotActive: {
    backgroundColor: colors.cyan,
    width: 8,
  },
  hashtagsRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: 4,
  },
  hashtagBadge: {
    color: colors.cyan,
    fontSize: 12,
    fontWeight: "600",
  },
});
