import React, { useEffect } from "react";
import { StyleSheet, Text } from "react-native";

import { useApp } from "../state/AppContext";
import { colors } from "../theme/colors";

export function Toast() {
  const { toast, clearToast } = useApp();

  useEffect(() => {
    if (!toast) {
      return;
    }
    const timer = setTimeout(clearToast, 3200);
    return () => clearTimeout(timer);
  }, [clearToast, toast]);

  if (!toast) {
    return null;
  }

  return (
    <Text
      style={[
        styles.toast,
        toast.kind === "error" && styles.error,
        toast.kind === "success" && styles.success,
      ]}
    >
      {toast.message}
    </Text>
  );
}

const styles = StyleSheet.create({
  toast: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 20,
    zIndex: 20,
    borderRadius: 8,
    padding: 13,
    overflow: "hidden",
    color: "#ffffff",
    backgroundColor: colors.cardElevated,
    borderWidth: 1,
    borderColor: colors.borderLight,
    fontWeight: "700",
  },
  error: {
    backgroundColor: colors.danger,
    borderColor: colors.danger,
  },
  success: {
    backgroundColor: colors.emerald,
    borderColor: colors.emerald,
  },
});
